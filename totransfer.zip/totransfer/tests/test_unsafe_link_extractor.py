from emailutils import (
    get_sender_domains,
    parse_unsafe_links,
    get_unsafe_links_in_body,
    get_links_with_sender_domain,
    get_unsubscribe_links_in_headers,
    UnsubscribeLinkSearcher,
    AdpParsedEmail,
    unsafe_link_enums,
)
import pytest
import typing as T
from logging import getLogger


logger = getLogger("Result logger")

res_test_unsubscr_email_1_json = [
    (
        "mailto:example.com@in.header.net?subject=unsubscribe",
        unsafe_link_enums.UnsafeReason.HEADER.value,
    ),
    (
        "https://try.example.html1.com/unsubscribe",
        unsafe_link_enums.UnsafeReason.STEM_DISPLAYED_LINK.value,
    ),
    (
        "https://try.example.html2.com/unsubscribe",
        unsafe_link_enums.UnsafeReason.STEM_LINK.value,
    ),
    (
        "https://try.example.plain1.com/unsubscribe",
        unsafe_link_enums.UnsafeReason.STEM_LINK.value,
    ),
    (
        "https://try.example.plain2.com/unsubscribe",
        unsafe_link_enums.UnsafeReason.STEM_LINK.value,
    ),
]

res_test_unsubscr_email_2_json = [
    (
        "mailto:bounce@am.kohls.com?subject=unsubscribe%3CAC700000003A515386E277204F2kohls_mkt_prod2@am.kohls.com%3E",
        unsafe_link_enums.UnsafeReason.HEADER.value,
    ),
    (
        "https://pages.am.kohls.com/lp/example",
        unsafe_link_enums.UnsafeReason.STEM_CONTEXT.value,
    ),
    (
        "https://t.am.kohls.com/r/example",
        unsafe_link_enums.UnsafeReason.STEM_DISPLAYED_LINK.value,
    ),
]

res_test_unsubscr_email_3_json = [
    (
        "mailto:example@unsubscribe.netline.com?subject=Unsubscribe",
        unsafe_link_enums.UnsafeReason.HEADER.value,
    ),
    (
        "https://my.netline.com/tradepub0003/?_m=0a.09xm.3fc.ct08k8n83h.0",
        unsafe_link_enums.UnsafeReason.HEADER.value,
    ),
    (
        "https://my.netline.com/tradepub0003/?_m=0a.09xm.3fc.ct08k8n83h.14",
        unsafe_link_enums.UnsafeReason.STEM_CONTEXT.value,
    ),
    (
        "https://my.netline.com/tradepub0003/?_m=0a.09xm.3fc.ct08k8n83h.1g",
        unsafe_link_enums.UnsafeReason.STEM_DISPLAYED_LINK.value,
    ),
]

@pytest.mark.parametrize(
    "test_email_file,res_sender_domains",
    [("shadowserver_a.json", ["leading.ml"])],
)
def test_get_sender_domains(
    test_email_file: str, res_sender_domains: T.List, data_dir: str
):
    parsed_email = AdpParsedEmail.from_json(test_email_file, data_dir=data_dir)

    sender_domains_in_header = get_sender_domains(parsed_email.headers())
    assert len(sender_domains_in_header) == len(
        res_sender_domains
    ), "Number of domains doesn't match"
    assert all(
        [a == b for a, b in zip(sender_domains_in_header, res_sender_domains)]
    ), "Not the expected domains in header"


@pytest.mark.parametrize(
    "test_email_file,res_links_with_sender_domain",
    [
        (
            "shadowserver_a.json",
            [
                (
                    "https://www.leading.ml/",
                    unsafe_link_enums.UnsafeReason.DOMAIN.value,
                ),
            ],
        )
    ],
)
def test_get_links_with_sender_domain(
    test_email_file: str, res_links_with_sender_domain: T.List, data_dir: str
):
    parsed_email = AdpParsedEmail.from_json(test_email_file, data_dir=data_dir)

    links_with_sender_domain = get_links_with_sender_domain(
        parsed_email.text_parts(), parsed_email.headers()
    )
    assert all(
        [a == b for a, b in zip(links_with_sender_domain, res_links_with_sender_domain)]
    ), "Not the expected links with the sender's domain"


@pytest.mark.parametrize(
    "test_email_file,res_text_parts,res_links_with_sender_domain",
    [
        (
            "shadowserver_a.json",
            ["TEXT_TYPE_PLAIN", "TEXT_TYPE_HTML"],
            [
                (
                    "https://www.leading.ml/",
                    unsafe_link_enums.UnsafeReason.DOMAIN.value,
                ),
            ],
        )
    ],
)
def test_parse_unsafe_links(
    test_email_file: str,
    res_text_parts: T.List,
    res_links_with_sender_domain: T.List,
    data_dir: str,
):
    parsed_email = AdpParsedEmail.from_json(test_email_file, data_dir=data_dir)
    unsafe_links = parse_unsafe_links(parsed_email.headers(), parsed_email.text_parts())
    assert True


@pytest.mark.parametrize(
    "test_email_file,res_unsafe_links",
    [
        (
            "test_unsubscr_email_1.json",
            res_test_unsubscr_email_1_json,
        ),
        (
            "test_unsubscr_email_2.json",
            res_test_unsubscr_email_2_json,
        ),
        (
            "test_unsubscr_email_3.json",
            res_test_unsubscr_email_3_json,
        ),
    ],
)
def test_parse_unsubscribe_links(
    test_email_file: str, res_unsafe_links: T.List, data_dir: str
):
    parsed_email = AdpParsedEmail.from_json(test_email_file, data_dir=data_dir)
    unsafe_links = parse_unsafe_links(
        parsed_email.headers(),
        parsed_email.text_parts(),
        stems=[
            "unsubscr",
            "click here",
            "stop receiving",
            "no longer wish to receive",
            "no longer receive",
            "stop getting",
        ],
    )
    logger.info(f"Found {len(unsafe_links)} links")
    logger.info(f"Links: {unsafe_links}")
    assert len(unsafe_links) >= len(res_unsafe_links)
    assert all(i in unsafe_links for i in res_unsafe_links)
