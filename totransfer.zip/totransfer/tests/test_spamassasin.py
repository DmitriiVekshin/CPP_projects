import os.path
from emailutils import SpamassasinDockerContainer
import asyncio
import time
import logging
import pytest
from emailutils import AdpParsedEmail


@pytest.mark.skipif(os.path.isfile('/.dockerenv'), reason="Running in teamcity docker container")
def test_spamassasin_with_example():
    sa = SpamassasinDockerContainer.get_instance()
    time.sleep(1.4)
    example_message = ('From: John Doe <jdoe@machine.example>'
                       'To: Mary Smith <mary@example.net>'
                       'Subject: Saying Hello'
                       'Date: Fri, 21 Nov 1997 09:55:06 -0600'
                       'Message-ID: <1234@local.machine.example>'
                       ''
                       'This is a message just to say hello.'
                       'So, "Hello".').encode('ascii')
    response = sa.check_for_spam_blocking(example_message)
    logging.info(
        f"Is the message spam? {response.headers['Spam'].value} ; " + \
        f"The score and threshold is {response.headers['Spam'].score} " + \
        f"/ {response.headers['Spam'].threshold}")
    score = response.headers['Spam'].score
    assert response.headers['Spam'].value, 'The message should be classified as spam'
    assert score > 10., f'The score should be 15.6 ({score})'


@pytest.mark.parametrize(
    "test_eml_file, is_spam",
    [("mailpot-test-email-1.eml", False),
     ("mailpot-test-email-2.eml", True)],
)
@pytest.mark.skipif(os.path.isfile('/.dockerenv'), reason="Running in teamcity docker container")
def test_spamassasin_from_adp_parser_email(test_eml_file, is_spam, data_dir):
    # eml = load_eml(os.path.join(data_dir, test_eml_file))
    parsed_email = AdpParsedEmail.from_eml(test_eml_file, data_dir)
    sa = SpamassasinDockerContainer.get_instance()
    time.sleep(1.4)
    response = sa.check_for_spam_blocking(parsed_email.eml)
    logging.info(
        f"Is the message spam? {response.headers['Spam'].value} ; " + \
        f"The score and threshold is {response.headers['Spam'].score} " + \
        f"/ {response.headers['Spam'].threshold}")
    verdict = response.headers['Spam'].value
    score = response.headers['Spam'].score
    assert verdict is is_spam


@pytest.mark.parametrize(
    "test_eml_files, is_spam",
    [(["mailpot-test-email-1.eml","mailpot-test-email-2.eml"],
      [False, True])],
)
@pytest.mark.skipif(os.path.isfile('/.dockerenv'), reason="Running in teamcity docker container")
def test_spamassasin_from_adp_parser_email(test_eml_files, is_spam, data_dir):
    parsed_emails = [AdpParsedEmail.from_eml(test_eml_file, data_dir).eml for test_eml_file in test_eml_files]
    sa = SpamassasinDockerContainer.get_instance()
    time.sleep(1.4)
    loop = asyncio.get_event_loop()
    results = loop.run_until_complete(sa.check_for_spam_parallel(parsed_emails))
    assert len(results) == 2

def load_eml(file):
    with open(file, "r") as fp:
        return fp.read().encode('ascii')

