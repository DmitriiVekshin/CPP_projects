from emailutils import PageLink, LinkContextHTMLParser


def get_text_data():
    return """

    Example  <a href='example.com'>  link text  </a> here. Example of image <img src=''/> is here.

    <table>
    <tr>
        <td>
            <a href="http://www.facebook.com/groupon"><img src="http://s3.grouponcdn.com/email/images/mindstorm/social/icon-facebook-white.png"/></a>&nbsp;
        </td>
        <td>
            <a href="http://www.twitter.com/groupon"><img src="http://s3.grouponcdn.com/email/images/mindstorm/social/icon-twitter-white.png"/ alt='twitter'>&nbsp;</a>
        </td>
        <td>
            <a href="http://www.pinterest.com/groupon"><img src="http://s3.grouponcdn.com/email/images/mindstorm/social/icon-pinterest-white.png" alt-custom="pinterest"/></a>
        </td>
    </tr>
    </table>

    """


def test_url_in_text_parser():
    handler = LinkContextHTMLParser()
    parsed = handler.handle("http://example.com")
    assert len(parsed) == 1
    assert isinstance(parsed[0], PageLink)


def test_text_parser():
    parsed = LinkContextHTMLParser().handle(get_text_data())
    assert len(parsed) == 9
    # from </td>:
    assert parsed.count(".") == 3

    texts = [i if isinstance(i, str) else i.text for i in parsed]

    assert not all([t.startswith("/n") or t.startswith(" ") for t in texts])

    assert not all([t.endswith("/n") or t.endswith(" ") for t in texts])

    links = [i for i in parsed if isinstance(i, PageLink)]
    assert len(links) == 4
    # pinterest: has custom alt
    assert not links[3].text
    # twitter: has alt
    assert links[2].text == "twitter"
    # fb: has no alt
    assert not links[1].text
    # simple link
    assert links[0].text == "link text"
