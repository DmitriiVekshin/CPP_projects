import pytest
import os
import logging
from emailutils import unsafe_link_enums


@pytest.fixture
def data_dir(request):
    modulepath = str(request.fspath)
    rootpath = modulepath[0 : modulepath.rfind("/")]
    return os.path.join(rootpath, "data")
