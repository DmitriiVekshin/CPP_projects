import pytest
from emailutils import AdpParsedEmail


@pytest.mark.parametrize(
    "test_email_file,num_headers,res_text_parts",
    [("shadowserver_a.json", 11, ["TEXT_TYPE_PLAIN", "TEXT_TYPE_HTML"])],
)
def test_from_json(test_email_file, num_headers, res_text_parts, data_dir):
    parsed_email = AdpParsedEmail.from_json(test_email_file, data_dir=data_dir)
    assert len(parsed_email.headers()) == num_headers

    text_parts = parsed_email.text_parts()
    assert len(text_parts) == len(res_text_parts), "Number of text parts doesn't match"

    assert all([a == b for a, b in zip(map(lambda x: x['type'], text_parts), res_text_parts)]), \
        "Not the expected text parts"


@pytest.mark.parametrize(
    "test_email_file,num_headers,res_text_parts",
    [("shadowserver_a.json", 11, ['TEXT_TYPE_PLAIN', 'TEXT_TYPE_HTML'])],
)
def test_from_eml(test_email_file, num_headers, res_text_parts, data_dir):
    assert True
