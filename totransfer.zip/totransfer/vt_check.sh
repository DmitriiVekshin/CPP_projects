#!/bin/bash


search_dir=/Users/dmitriivekshin/Documents/Study/SBF/task1/suspicious/
for entry in "$search_dir"/*
do
    
    echo $entry
    variable=$(sha256sum $entry | awk '{ print $1 }')

    
    echo $variable
    
    curl -s -X POST 'https://www.virustotal.com/vtapi/v2/file/report' --form apikey="3bc7b9e754b51f456ea411a90277422da86e8e9a1809b541211afe6aeb4447d0" --form resource=$variable | awk -F 'positives\":' '{print "VT Hits_" $2}' | awk -F ' ' '{print $1$2$3$6$7}' | sed 's|["}]||g'
    sleep 15
done