from enum import Enum


class UnsafeReason(Enum):
    DOMAIN = "Link contains sender domain"
    STEM_LINK = "Link body contains stem"
    HEADER = "Link in header with stem"
    STEM_CONTEXT = "Link context contains stem"
    STEM_DISPLAYED_LINK = "Displayed link body contains stem"
