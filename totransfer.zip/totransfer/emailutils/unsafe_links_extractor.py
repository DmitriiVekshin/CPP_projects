import typing as T
from emailutils import UnsubscribeLinkSearcher

from malkovich.domain import get_domain_name
from urlextract import URLExtract
import itertools
from emailutils import UnsafeReason


# The function parse domain form email address
def parse_domain_from_eml_addr(header: str) -> str:
    header = header.split("@")[-1]
    header_chars_list = list(
        [
            val
            for val in header
            if val.isalpha() or val.isnumeric() or val == "." or val == "-"
        ]
    )
    header = "".join(header_chars_list)
    return get_domain_name(header)


# The function parse domains related to sender from following headers:
# mail-reply-to, authenticated-sender, from, sender, reply-to, return-path
# also X- versions of this headers (e.g.: X-sender)
def get_sender_domains(headers: T.List) -> T.Set:
    return {
        parse_domain_from_eml_addr(domain)
        for h in headers
        if "from" in h["name"].lower()
        or "sender" in h["name"].lower()
        or "reply-to" in h["name"].lower()
        or "return-path" in h["name"].lower()
        for domain in h["value"].split(",")
    }


# The function returns a list of links that contains related to sender domain
def get_links_with_sender_domain(body: T.List, headers: T.List) -> T.List:
    return [
        (l, UnsafeReason.DOMAIN.value)
        for d in get_sender_domains(headers)
        for body_part in body
        for l in URLExtract().find_urls(body_part["body"])
        if d and d in l.lower()
    ]


def is_html(body_part: T.Dict) -> bool:
    return body_part["type"] == "TEXT_TYPE_HTML"


# The function returns a list unsubscribe links parsed from email body
def get_unsafe_links_in_body(
    body: T.List, stems: T.List[str], context_len: int
) -> T.List:
    return [
        (l.url, r)
        for stem in stems
        for body_part in body
        for l, r in UnsubscribeLinkSearcher(
            context_len, stem, html=is_html(body_part)
        ).get_unsubscribe_links(body_part["body"])
        if l.url
    ]


# The function returns a list unsubscribe links parsed from email headers
def get_unsubscribe_links_in_headers(headers: T.List, stems: T.List[str]) -> T.List:
    return [
        (link.lstrip("\n\t <").rstrip("> \n\t"), UnsafeReason.HEADER.value)
        for stem in stems
        for h in headers
        if stem in h["name"].lower()
        for link in h["value"].split(",")
    ]


# The function parse unsafe links from email body and headers by following stem
# context_len parameter defines the number of words before the link (link's context) to be analyzed
def parse_unsafe_links(
    headers: T.List,
    body: T.List,
    context_len: int = 20,
    stems: T.Optional[T.List[str]] = None,
) -> T.List:
    if stems is None:
        stems = ["unsubscr"]
    return list(
        itertools.chain(
            get_unsubscribe_links_in_headers(headers, stems),
            get_unsafe_links_in_body(body, stems, context_len),
            # get_links_with_sender_domain(body, headers),
        )
    )
