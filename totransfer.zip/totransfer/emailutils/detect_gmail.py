import argparse
from email.message import EmailMessage
from email.parser import BytesParser
from email.policy import default
from pathlib import Path
from typing import Any, Dict

from anttools.tools import get_sha256

FileResult = Dict[str, Any]


def is_sent_via_google(email: EmailMessage) -> bool:
    if "X-Google-Smtp-Source" in email:
        return True
    if "Received-SPF" in email and "google.com" in email["Received-SPF"]:
        return True
    if "Received" in email and "google.com" in email["Received"]:
        return True
    if "X-Received" in email and "google.com" in email["X-Received"]:
        return True
    if (
        "Authentication-Results" in email
        and "mx.google.com" in email["Authentication-Results"]
    ):
        return True
    # TODO: If Auth passed and sender/receiver is from google.com/gmail.com
    return False


def analyse_folder(folder_path: Path) -> None:
    for filename in folder_path.glob("**/*"):
        if filename.is_file():
            file_path = folder_path / filename

            file_result = process_file(file_path)
            if file_result["google_infra"]:
                print(file_path, file_result["google_infra"])


def process_file(eml_path: Path) -> FileResult:
    with open(eml_path, "rb") as input_file:
        file_contents = input_file.read()
        input_file.seek(0)
        headers = BytesParser(policy=default).parse(input_file)

    return {
        "file_sha256": get_sha256(file_contents),
        "google_infra": is_sent_via_google(headers),
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-d",
        dest="directory",
        help="Input directory.",
    )
    args = parser.parse_args()
    if not args.directory:
        print("Requires input directory")
    else:
        analyse_folder(Path(args.directory))
