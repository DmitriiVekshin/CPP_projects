import logging
import atexit
import docker
from emailutils import AdpParsedEmail
import aiospamc
import asyncio


FORMAT = '%(asctime)-15s %(message)s'
logging.basicConfig(format=FORMAT, level=logging.INFO)


class SpamassasinDockerContainer:
    IMAGE = 'blackplane/spamassasin:latest'
    PORT = 32211
    __instance__ = None

    @staticmethod
    def get_instance(args=dict()):
        """ Static method to fetch the current instance."""
        if not SpamassasinDockerContainer.__instance__:
            SpamassasinDockerContainer(args)
        return SpamassasinDockerContainer.__instance__

    def __init__(self, args=dict()):
        if SpamassasinDockerContainer.__instance__ is None:
            SpamassasinDockerContainer.__instance__ = self
        else:
            raise Exception("You cannot create another singleton SpamassasinDockerContainer class")
        image = args.get('image', SpamassasinDockerContainer.IMAGE)
        port = args.get('port', SpamassasinDockerContainer.PORT)
        self.client = docker.from_env()
        self.container = self.client.containers.run(image, detach=True, remove=True, ports={'783/tcp': port})
        logging.info("Starting SpamassasinDockerContainer")
        atexit.register(self.cleanup)

    def cleanup(self):
        logging.info('Goodbye.')
        self.container.stop()

    async def check_for_spam(self, message):
        response = await aiospamc.check(message, host='localhost', port=32211)
        return response

    def check_for_spam_blocking(self, message):
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(self.check_for_spam(message))

    async def check_for_spam_parallel(self, messages):
        # loop = asyncio.get_event_loop()
        tasks = [aiospamc.check(message, host='localhost', port=32211) for message in messages]
        result = await asyncio.gather(*tasks)
        return result


    def load_spam_assassine_score(self, email: AdpParsedEmail):
        return

# def load_spam_assassine_score(eml):
#     import subprocess
#
#     docker_mount = eml.filename + ":/samples"
#     result = subprocess.run(["sudo", "docker", "run", "--rm", "-v", "/home/dimi/shared/mails:/samples", "spam-ass", "/samples"], stdout=subprocess.PIPE)
#     spamassassin_out = str(result.stdout)
#     count_line = 0
#     i = len(spamassassin_out) - 1
#     while i != 1:
#         if spamassassin_out[i] == '\\':
#             count_line += 1
#         if count_line == 10:
#             break
#         i -= 1
#     spamassassin_out = spamassassin_out[i:]
#     print(spamassassin_out)