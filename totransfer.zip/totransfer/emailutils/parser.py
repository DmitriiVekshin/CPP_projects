import re
import string
import typing as T
from dataclasses import dataclass
from html.parser import HTMLParser
import nltk
from urlextract import URLExtract
import logging
from emailutils import UnsafeReason
import os


@dataclass
class PageLink:
    text: str
    url: str
    context: str = ""


class LinkContextHTMLParser(HTMLParser):
    """
    Processes HTML into a list of str and page links.

    String 'This is an example <a href="http://example.com">link</a>!' will be processed as
    ['this is an example', PageLink(text='link', url='http://example.com'), '!']

    """

    def __init__(self):
        super().__init__()
        self.a = None
        self.link_text = []
        self._lines = []
        self.quite = False

        self.unicode_pattern = re.compile(r"[^\x00-\x7F]+")
        self.url_extractor = URLExtract()

    def error(self, message):
        pass

    def handle(self, data):
        # clear the current output before re-use
        self._lines = []
        # re-set the parser's state before re-use
        self.reset()
        self.feed(data)
        self.close()
        return self.join(self._lines)

    def feed(self, data):
        data = data.replace("</' + 'script>", "</ignore>")
        HTMLParser.feed(self, data)

    @staticmethod
    def join(lines: list):
        buff = []
        new_lines = []
        for i in lines:
            if isinstance(i, PageLink):
                if buff:
                    new_lines.append(" ".join(buff))
                new_lines.append(i)
                buff = []
            else:
                buff.append(i)
        if buff:
            new_lines.append(" ".join(buff))
        return new_lines

    def handle_starttag(self, tag, attrs):
        if tag in ["head", "style", "script"]:
            self.quite = True

        if self.quite:
            self.a = None
            return

        if attrs:
            attrs = dict(attrs)
        else:
            attrs = {}

        if tag == "a" and attrs.get("href"):
            self.a = attrs.get("href")
        if tag == "img":
            self.handle_data(attrs.get("alt", ""))

    def handle_endtag(self, tag):
        if tag in ["head", "style", "script"]:
            self.quite = False

        if tag == "a":
            self._lines.append(PageLink(text=" ".join(self.link_text), url=self.a))
            self.a = None
            self.link_text = []

        if tag in ["li", "td"]:
            self.handle_data(".")

    def normalize(self, text):
        s = self.unicode_pattern.sub(" ", text).strip()
        s = " ".join([si for si in s.splitlines() if si.strip()])
        return s if any(c.isalpha() or c in string.punctuation for c in s) else ""

    def _process_in_body_urls(self, data: str):
        urls = self.url_extractor.find_urls(data)
        for word in data.split():
            if not word.strip():
                continue
            if word in urls:
                self._lines.append(PageLink(text="", url=word))
            else:
                self._lines.append(word)

    def handle_data(self, data):
        if self.quite:
            return

        if not data:
            return

        data = self.normalize(data.strip())
        if not data:
            return

        if data == "." and (not self._lines or self._lines[-1] == "." or self.a):
            return
        if self.a:
            self.link_text.append(data)
        else:
            self._process_in_body_urls(data)


class LinkContextPLAINParser:
    """
    Processes HTML into a list of str and page links.

    String 'This is an example <a href="http://example.com">link</a>!' will be processed as
    ['this is an example', PageLink(text='link', url='http://example.com'), '!']

    """

    def __init__(self):
        self._lines = []
        self.url_extractor = URLExtract()
        self.unicode_pattern = re.compile(r"[^\x00-\x7F]+")

    def error(self, message):
        pass

    def handle(self, data: str):
        self._lines = []
        self.feed(data)

        return self.join(self._lines)

    def feed(self, data: str):
        if not data:
            return

        data = self.normalize(data.strip())
        if not data:
            return
        self._process_in_body_urls(data)

    def _process_in_body_urls(self, data: str):
        urls = self.url_extractor.find_urls(data)
        for word in data.split():
            if not word.strip():
                continue
            if word in urls:
                self._lines.append(PageLink(text="", url=word))
            else:
                self._lines.append(word)

    @staticmethod
    def join(lines: list) -> list:
        buff = []
        new_lines = []
        for i in lines:
            if isinstance(i, PageLink):
                if buff:
                    new_lines.append(" ".join(buff))
                new_lines.append(i)
                buff = []
            else:
                buff.append(i)
        if buff:
            new_lines.append(" ".join(buff))
        return new_lines

    def normalize(self, text: str) -> str:
        punctuation = "()<>[]{}"
        s = self.unicode_pattern.sub(" ", text).strip()
        for char in punctuation:
            s = s.replace(char, " ")
        s = " ".join([si for si in s.splitlines() if si.strip()])
        return s if any(c.isalpha() or c in string.punctuation for c in s) else ""


class UnsubscribeLinkSearcher:
    def __init__(
        self, context_max_words: int = 20, stem: str = "unsubscr", html: bool = True
    ):
        # Find nltk data dir: current dir -> NLTK_DATA -> HOME -> /usr/local/share/nltk_data -> /usr/share/nltk_data
        self.nltk_tokenizer = get_nltk_data_dir("tokenizers/punkt/english.pickle")
        logging.info(f"Using nltk tokenizer file from {self.nltk_tokenizer}")
        self.context_max_words = context_max_words
        self.stem = stem
        self.tokenizer = nltk.data.load(self.nltk_tokenizer)
        self.translator = str.maketrans(
            string.punctuation, " " * len(string.punctuation)
        )
        if html:
            self.html_parser = LinkContextHTMLParser()
        else:
            self.html_parser = LinkContextPLAINParser()

    def _reduce_context(self, context: str) -> str:
        sentences = self.tokenizer.tokenize(context)
        # heuristic
        relevant_context_start = [
            i for i, ci in enumerate(sentences) if len(ci.strip()) > len(self.stem)
        ]
        if not relevant_context_start:
            # not enough context
            return ""

        relevant_context = " ".join(sentences[max(relevant_context_start) :])
        relevant_context = relevant_context.translate(self.translator)
        words = relevant_context.split()
        if len(words) > self.context_max_words:
            words = words[-self.context_max_words :]
        relevant_context = " ".join([w for w in words if w.strip()])
        return relevant_context

    def get_unsubscribe_links(self, body_html: str) -> T.List[PageLink]:
        parsed = self.html_parser.handle(body_html)

        unsubscribe = []

        for context, item in zip(["", *parsed], [*parsed, ""]):

            if not isinstance(item, PageLink):
                continue

            # stem is in the link text:
            if item.text and self.stem in item.text.lower():
                unsubscribe.append((item, UnsafeReason.STEM_DISPLAYED_LINK.value))
                continue

            # stem is directly in the url:
            if item.url and self.stem in item.url.lower():
                unsubscribe.append((item, UnsafeReason.STEM_LINK.value))
                continue

            # now check previous context
            if isinstance(context, PageLink):
                # no context if context is a link
                continue
            relevant_context = self._reduce_context(context)
            if self.stem in relevant_context.lower():
                item.context = relevant_context
                unsubscribe.append((item, UnsafeReason.STEM_CONTEXT.value))

        return [(link, reason) for link, reason in unsubscribe if link.url]


def get_nltk_data_dir(resource):
    """Find nltk data dir: current dir -> NLTK_DATA -> HOME -> /usr/local/share/nltk_data -> /usr/share/nltk_data"""

    nltk_resources = [
        os.getcwd(),
        os.path.join(os.getcwd(), ".."),
        os.environ.get("NLTK_DATA", None),
        os.environ.get("HOME", None),
        os.path.join(os.environ.get("HOME", ""), "nltk_data"),
        "/usr/local/share/nltk_data",
        "/usr/share/nltk_data",
    ]
    nltk_resources = [
        os.path.join(p, resource) for p in nltk_resources if p is not None
    ]
    for nltk_resource in nltk_resources:
        if os.path.exists(nltk_resource):
            return nltk_resource
    raise ValueError(f"No nltk_resource {resource} found in {nltk_resources}")
