import os
import typing as T
import asyncio
import concurrent.futures
import requests
import json
import logging
from queue import Queue
from codetiming import Timer
import hashlib


class AdpProcessorEndpoint:
    def __init__(self, apd_processor_ep='https://adp-processor.svc.avast.com/api/v1/process'):
        self.apd_processor_ep = apd_processor_ep
        self.errors = []
        self.elapsed = []
        self.results = Queue(maxsize=0)
        self.timer = Timer(name=f'timer-{self.__class__}', logger=None)

    def eml_to_json(self, m):
        try:
            res = requests.post(url=self.apd_processor_ep,
                                data=bytes(m),
                                headers={'Content-Type': 'application/octet-stream'})
            h = hashlib.sha256(bytes(m)).hexdigest().upper()
            js = json.loads(res.text)
        except Exception as ex:
            self.errors.append((m, ex))
            return None
        return (js, h)

    def sequential_post(self, messages) -> T.List:
        return [
            self.eml_to_json(m)
            for m in messages if m
        ]

    async def parallel_post(self, messages, max_workers=100):
        assert len(messages) < max_workers, 'Too many messages for threadpool'
        self.timer.start()
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            loop = asyncio.get_event_loop()
            futures = [
                loop.run_in_executor(
                    executor,
                    self.eml_to_json,
                    m
                )
                for i, m in enumerate(messages)
            ]
            results = await asyncio.gather(*futures)
            processing_time = self.timer.stop()
            logging.info(f"Processed {len(results)} records in {processing_time:.2f} s")
            for idx, response in enumerate(results):
                self.results.put((idx, response, processing_time))


class AdpParsedEmail:
    """Wrapper class for ParsedEmail in protobuf spec"""

    def __init__(self, parsed_email: T.Dict):
        self.parsed_email = parsed_email
        self._eml = ''

    def headers(self):
        if self.parsed_email is None:
            return None

        return self.parsed_email["parsed"]["headers"]

    def text_parts(self):
        if self.parsed_email is None:
            return None
        
        return self.parsed_email["parsed"]["textParts"]


    @staticmethod
    def from_json(json_file, data_dir="."):
        with open(os.path.join(data_dir, json_file), "r") as fp:
            return AdpParsedEmail(json.load(fp))

    @staticmethod
    def from_eml(eml_file, data_dir='.'):
        with open(os.path.join(data_dir, eml_file), 'r') as fp:
            eml = fp.read().encode('ascii')
        obj = AdpParsedEmail(None)
        obj.eml = eml
        #TODO send eml to adp parser
        return obj

    @property
    def eml(self):
        return self._eml

    @eml.setter
    def eml(self, eml_text):
        self._eml = eml_text
