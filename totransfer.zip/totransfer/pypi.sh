#!/usr/bin/env bash

set -euo pipefail

if [[ -z "${ARTIFACTORY_URL-}" ]]; then
  ARTIFACTORY_URL="https://artifactory.ida.avast.com/artifactory/api/pypi/pypi-local/simple"
fi

lib=${PWD}

function upload_to_pypi {
  if [[ -n "${SKIP_UPLOAD+x}" ]]; then
    echo "Skipping upload_to_pypi"
    return
  fi

  if [[ -z "${ARTIFACTORY_USERNAME-}" ]]; then
    echo -n Artifactory username:
    read ARTIFACTORY_USERNAME
  fi

  if [[ -z "${ARTIFACTORY_PASSWORD-}" ]]; then
    echo -n Artifactory password:
    read -s ARTIFACTORY_PASSWORD
  fi

  twine upload \
  --skip-existing \
  --repository-url "${ARTIFACTORY_URL}" \
  -u "${ARTIFACTORY_USERNAME}" \
  -p "${ARTIFACTORY_PASSWORD}" \
  "dist/*"
}



>&2 echo "Running build "
python setup.py bdist_wheel
>&2 echo "Publishing emailutils to ${ARTIFACTORY_URL}"
upload_to_pypi
rm -rf build
rm -rf dist
rm -rf *.egg-info
