from os import listdir
from os.path import isfile, join

from emailutils import AdpProcessorEndpoint
import logging
from tqdm import tqdm
import os
import logging
import argparse
import pandas as pd
import numpy as np
import hashlib
from codetiming import Timer
import asyncio
import json
import typing as T

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(threadName)s %(name)s %(message)s",
)
logging.basicConfig(
    level=logging.ERROR,
    format="%(asctime)s %(levelname)s %(threadName)s %(name)s %(message)s",
)


def split_in_batches(
    df: pd.DataFrame,
    batch_size: int = 100,
    estimated_processing_time_per_batch: float = 1.1,
) -> T.List:
    batch_num = (df.shape[0] // batch_size) + 1
    batches = np.array_split(df["message"].values, batch_num)
    logging.info(
        f"Expected time to completion "
        f"{((df.shape[0] // batch_size) * estimated_processing_time_per_batch) / 60 ** 2:.2f} "
        f"h for {len(batches)} batches"
    )
    s = pd.DataFrame(list(map(len, batches)), columns=["batch_size"], dtype=int)
    s["batch_size"] = s["batch_size"].astype(int)
    s["count"] = 1
    logging.info(f"{s.groupby('batch_size').count()}")
    return batches


def files_paths2df(files_paths: T.List) -> pd.DataFrame:
    data = []
    for path in files_paths:
        try:
            with open(path, "r") as fp:
                content = fp.read().encode("utf-8")
        except Exception as e:
            logging.error(f"Cannot read a file {path}. Exception: {e}.")
            continue
        data.append([path, content])
    return pd.DataFrame(data, columns=["file", "message"])


def load_csv(csv: str) -> pd.DataFrame:
    return pd.read_csv(csv)


def load_file(file: str) -> pd.DataFrame:
    return files_paths2df([file])


def load_dir(dir: str) -> pd.DataFrame:
    return files_paths2df([join(dir, f) for f in listdir(dir) if isfile(join(dir, f))])


def load_data(args):
    if args.csv:
        logging.info(f"Processing a CSV: {args.csv}")
        df = load_csv(args.csv)
    elif args.file:
        logging.info(f"Processing a single file: {args.file}")
        df = load_file(args.file)
    elif args.dir:
        logging.info(f"Processing all files in dir: {args.dir}")
        df = load_dir(args.dir)
    else:
        logging.error(f"Error: target is not specified.")
        return None
    return df


def process_and_store_data_sync(
    batches: T.List, ep: AdpProcessorEndpoint, out_dir: str
):
    for batch in batches:
        try:
            res = ep.sequential_post(batch)
            for r in res:
                if not r:
                    continue
                with open(os.path.join(out_dir, "".join([r[1], ".dat"])), "w") as fo:
                    json.dump(r[0], fo, ensure_ascii=False, indent=4)
        except Exception as e:
            logging.error(f"Parsing error. Exception: {e}.")

    with open("errors.log", "w", encoding="utf-8") as f:
        json.dump(str(ep.errors), f, ensure_ascii=False, indent=4)


def process_and_store_data_async(
    batches: T.List, ep: AdpProcessorEndpoint, number_batches: int
):
    t = Timer(name="t3", logger=None)
    loop = asyncio.get_event_loop()
    elapsed = []
    processing_time_total = 0.0

    if number_batches > 0:
        batches = batches[0:number_batches]

    for j, batch in enumerate(batches):
        t.start()
        loop.run_until_complete(ep.parallel_post(batch))
        elapsed.append(t.stop())

    num_records_received = ep.results.qsize()
    processed = 0
    logging.info(f"Received {num_records_received} records in the queue")
    with open("data.json", "w", encoding="utf-8") as f:
        while not ep.results.empty() and processed != num_records_received:
            idx, item, processing_time = ep.results.get()
            if item is None:
                continue
            processing_time_total += processing_time
            js, h = item
            json.dump({h: js}, f, ensure_ascii=False, indent=4)
            processed += 1
    logging.info(
        f"Written records from queue to disk and total time is {processing_time_total:.2f} s, "
        f"that's {processing_time_total // num_records_received} s/record"
    )

    with open("errors.log", "w", encoding="utf-8") as f:
        json.dump(str(ep.errors), f, ensure_ascii=False, indent=4)


def parse_args():
    parser = argparse.ArgumentParser(
        description="The program parse emails to json format. "
        "The program use ADP parser from https://git.int.avast.com/cbs/adp-processor . "
        "Json format is defined here: "
        "https://git.int.avast.com/cbs/adp-contract/blob/master/src/main/protobuf/com/avast/cbs/adp/contract/Contract.proto . "
        "The programs works with email files or csv file. "
        "After reading the file, it send to "
        "ADP endpoint https://adp-processor.svc.avast.com/api/v1/process "
        "and then getting the response contained json with parsed email. "
        "Arguments: The target is required - it can be a single email file, "
        "a directory with emails or a csv file: resp. "
        "-f file_name or -d dir_name or -c csv_name. "
        "Optionally -b bathes_size and -n number_bathes can be specified. "
        "Attention, size of bathes have to be less then 100."
        "Example: python3 eml2json.py -f my_email.eml"
    )
    parser.add_argument(
        "-d", "--dir", help="Directory where the eml files are", type=str
    )
    parser.add_argument("-f", "--file", help="Eml files path", type=str)
    parser.add_argument("-c", "--csv", help="Point to the email csv file", type=str)
    parser.add_argument(
        "-b",
        "--batch-size",
        help="Size of the batches to process. Max is 100",
        type=int,
        default=100,
    )
    parser.add_argument(
        "-n",
        "--number-batches",
        help="Number of the batches to process",
        type=int,
        default=0,
    )
    parser.add_argument(
        "-o", "--out-dir", help="Dir to store the output", type=str, default="."
    )
    parser.add_argument(
        "-a", "--async-mode", help="Process emails in async mode", action="store_true"
    )
    args = parser.parse_args()
    logging.info(f"argparse {args}")
    return args, parser


def main():
    args, parser = parse_args()

    df = load_data(args)
    if df is None:
        parser.print_help()
        exit(0)

    if args.dir and args.out_dir == ".":
        input(
            f"You are trying to parse all files from {args.dir} to {os.path.dirname(os.path.abspath(__file__))}. "
            f"It will create {len(df)} new files in current dir.\nPress Enter to continue..."
        )

    ep = AdpProcessorEndpoint()
    batches = split_in_batches(df, batch_size=args.batch_size)

    if args.async_mode:
        process_and_store_data_async(batches, ep, args.number_batches)
    else:
        process_and_store_data_sync(batches, ep, args.out_dir)


if __name__ == "__main__":
    main()
